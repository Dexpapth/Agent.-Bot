import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import time
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from chatbot_core import get_response, verify_login, calculate_emi, CREDENTIALS

LIGHT = {
    "bg":          "#f4f6fb",
    "card":        "#ffffff",
    "primary":     "#1a3c6e",
    "accent":      "#f0a500",
    "text":        "#1c2231",
    "muted":       "#6b7280",
    "border":      "#dde3f0",
    "bot_bubble":  "#eef2ff",
    "user_bubble": "#1a3c6e",
    "user_text":   "#ffffff",
    "bot_text":    "#1c2231",
    "input_bg":    "#ffffff",
    "sidebar_btn": "#f4f6fb",
    "header":      "#1a3c6e",
    "header_text": "#ffffff",
}

DARK = {
    "bg":          "#0f1724",
    "card":        "#1a2234",
    "primary":     "#2b5aa0",
    "accent":      "#f0a500",
    "text":        "#e2e8f0",
    "muted":       "#8899bb",
    "border":      "#2a3a55",
    "bot_bubble":  "#1e2d45",
    "user_bubble": "#2b5aa0",
    "user_text":   "#ffffff",
    "bot_text":    "#e2e8f0",
    "input_bg":    "#0f1724",
    "sidebar_btn": "#0f1724",
    "header":      "#0a1628",
    "header_text": "#ffffff",
}


class LoginWindow:

    def __init__(self, root):
        self.root       = root
        self.role       = tk.StringVar(value="customer")
        self.fail_count = 0
        self.locked     = False
        self._build()

    def _build(self):
        self.root.title("BankBot AI — Login")
        self.root.geometry("420x560")
        self.root.resizable(False, False)
        self.root.configure(bg="#1a3c6e")

        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth()  - 420) // 2
        y = (self.root.winfo_screenheight() - 560) // 2
        self.root.geometry(f"420x560+{x}+{y}")

        card = tk.Frame(self.root, bg="white", bd=0, relief="flat")
        card.place(relx=0.5, rely=0.5, anchor="center", width=360, height=480)

        tk.Label(card, text="🏦", font=("Arial", 32), bg="white").pack(pady=(24,2))
        tk.Label(card, text="BankBot AI", font=("Arial", 18, "bold"), fg="#1a3c6e", bg="white").pack()
        tk.Label(card, text="Tkinter Desktop Edition", font=("Arial", 9), fg="#9ca3af", bg="white").pack(pady=(2,16))

        role_frame = tk.Frame(card, bg="#f4f6fb", bd=1, relief="flat")
        role_frame.pack(fill="x", padx=24)
        for role, label in [("customer","👤 Customer"), ("employee","🏦 Employee"), ("admin","🛡 Admin")]:
            tk.Radiobutton(
                role_frame, text=label, variable=self.role, value=role,
                bg="#f4f6fb", fg="#1a3c6e", font=("Arial", 10, "bold"),
                selectcolor="#dbeafe", activebackground="#f4f6fb",
                indicatoron=True, relief="flat", padx=8, pady=8
            ).pack(side="left", expand=True)

        tk.Label(card, text="Username", font=("Arial", 9, "bold"), fg="#6b7280", bg="white", anchor="w").pack(fill="x", padx=24, pady=(14,2))
        self.user_var = tk.StringVar()
        self.user_entry = tk.Entry(card, textvariable=self.user_var, font=("Arial", 11),
                                   relief="solid", bd=1, bg="white")
        self.user_entry.pack(fill="x", padx=24, ipady=6)

        tk.Label(card, text="Password", font=("Arial", 9, "bold"), fg="#6b7280", bg="white", anchor="w").pack(fill="x", padx=24, pady=(10,2))
        self.pass_var = tk.StringVar()
        self.pass_entry = tk.Entry(card, textvariable=self.pass_var, show="•",
                                   font=("Arial", 11), relief="solid", bd=1, bg="white")
        self.pass_entry.pack(fill="x", padx=24, ipady=6)
        self.pass_entry.bind("<Return>", lambda e: self.do_login())

        self.show_pass = False
        tk.Button(card, text="Show password", font=("Arial", 8), fg="#6b7280", bg="white",
                  relief="flat", cursor="hand2", bd=0,
                  command=self.toggle_pass).pack(anchor="e", padx=24)

        self.err_var = tk.StringVar()
        self.err_lbl = tk.Label(card, textvariable=self.err_var, font=("Arial", 9),
                                fg="#dc2626", bg="white", wraplength=300)
        self.err_lbl.pack(pady=(6,0))

        self.login_btn = tk.Button(
            card, text="🔐  Sign In", font=("Arial", 11, "bold"),
            bg="#1a3c6e", fg="white", relief="flat", cursor="hand2",
            activebackground="#2b5aa0", activeforeground="white",
            command=self.do_login
        )
        self.login_btn.pack(fill="x", padx=24, pady=(14,0), ipady=8)

        hint = (
            "Demo:  Customer → customer / bank123\n"
            "       Employee → employee / emp456\n"
            "       Admin    → admin    / admin789"
        )
        tk.Label(card, text=hint, font=("Arial", 8), fg="#3b5bcc",
                 bg="#f0f4ff", justify="left", padx=10, pady=8).pack(fill="x", padx=24, pady=(12,0))

        self.user_entry.focus()

    def toggle_pass(self):
        self.show_pass = not self.show_pass
        self.pass_entry.config(show="" if self.show_pass else "•")

    def do_login(self):
        if self.locked:
            return

        username = self.user_var.get().strip()
        password = self.pass_var.get()
        role     = self.role.get()

        if verify_login(username, password, role):
            self.err_var.set("")
            self.root.destroy()
            new_root = tk.Tk()
            app = ChatWindow(new_root, role)
            new_root.mainloop()
        else:
            self.fail_count += 1
            if self.fail_count >= 3:
                self._start_lockout()
            else:
                remaining = 3 - self.fail_count
                self.err_var.set(f"✗ Incorrect credentials. {remaining} attempt(s) left.")

    def _start_lockout(self):
        self.locked = True
        self.login_btn.config(state="disabled", bg="#9ca3af")

        def countdown(n):
            if n > 0:
                self.err_var.set(f"🔒 Too many attempts. Locked for {n}s")
                self.root.after(1000, countdown, n - 1)
            else:
                self.locked     = False
                self.fail_count = 0
                self.login_btn.config(state="normal", bg="#1a3c6e")
                self.err_var.set("Lockout ended. You may try again.")

        countdown(30)


class ChatWindow:

    def __init__(self, root, role):
        self.root       = root
        self.role       = role
        self.C          = LIGHT
        self.dark_mode  = False
        self.msg_count  = 0
        self.chat_log   = []
        self.start_time = time.time()
        self._typing_id = None

        self._build()
        self._start_session_timer()
        self.root.after(400, lambda: self._get_bot_reply("hello"))

    def _build(self):
        self.root.title(f"BankBot AI — {self.role.capitalize()} Session")
        self.root.geometry("1100x680")
        self.root.minsize(800, 500)
        self.root.configure(bg=self.C["bg"])

        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth()  - 1100) // 2
        y = (self.root.winfo_screenheight() - 680)  // 2
        self.root.geometry(f"1100x680+{x}+{y}")

        self._build_header()

        body = tk.Frame(self.root, bg=self.C["bg"])
        body.pack(fill="both", expand=True, padx=14, pady=(10,14))

        self._build_sidebar(body)
        self._build_chat(body)

    def _build_header(self):
        hdr = tk.Frame(self.root, bg=self.C["header"], height=52)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)

        tk.Label(hdr, text="🏦  BankBot AI", font=("Arial", 14, "bold"),
                 fg="white", bg=self.C["header"]).pack(side="left", padx=18)
        tk.Label(hdr, text="  Desktop Edition", font=("Arial", 9),
                 fg="rgba(255,255,255,0.6)", bg=self.C["header"]).pack(side="left")

        btn_cfg = dict(bg=self.C["header"], fg="white", relief="flat",
                       cursor="hand2", font=("Arial", 9), bd=0,
                       activebackground="#2b5aa0", activeforeground="white", padx=10, pady=4)

        tk.Button(hdr, text="🚪 Logout",    **btn_cfg, command=self._logout).pack(side="right", padx=6)
        tk.Button(hdr, text="🌙 Dark Mode", **btn_cfg, command=self._toggle_dark).pack(side="right")
        tk.Button(hdr, text="⬇ Export",    **btn_cfg, command=self._export_chat).pack(side="right")
        tk.Button(hdr, text="🗑 Clear",     **btn_cfg, command=self._clear_chat).pack(side="right")

        role_colors = {"customer": "#f0a500", "employee": "#3b82f6", "admin": "#16a34a"}
        badge_color = role_colors.get(self.role, "#f0a500")
        tk.Label(hdr, text=f"  {self.role.upper()}  ",
                 font=("Arial", 8, "bold"), fg="#1c1c1c",
                 bg=badge_color, padx=4, pady=2).pack(side="right", padx=8)

    def _build_sidebar(self, parent):
        self.sidebar = tk.Frame(parent, bg=self.C["bg"], width=210)
        self.sidebar.pack(side="left", fill="y", padx=(0,12))
        self.sidebar.pack_propagate(False)

        self._sb_section("⚡ Quick Actions")
        actions = [
            ("💳 Check Balance",    "Check my balance"),
            ("💸 Transfer Funds",   "Transfer money"),
            ("📋 Mini Statement",   "Show statement"),
            ("🏠 Loan Info",        "Loan information"),
            ("🧮 EMI Calculator",   "EMI calculator"),
            ("🔴 Block Card",       "Block my card"),
            ("🚨 Report Fraud",     "Report fraud"),
            ("📍 Find ATM",         "Nearest ATM"),
        ]
        if self.role in ("employee", "admin"):
            actions += [
                ("🔍 Customer Lookup", "Lookup customer"),
                ("⚠️ Error Log",      "System error"),
                ("📊 Daily Report",   "Daily report"),
                ("💻 System Status",  "System status"),
            ]
        for label, cmd in actions:
            self._sb_btn(label, cmd)

        self._sb_section("📈 Session Info")
        self.msg_lbl  = self._sb_stat("Messages", "0")
        self.time_lbl = self._sb_stat("Session",  "0m")

    def _sb_section(self, title):
        tk.Label(self.sidebar, text=title, font=("Arial", 8, "bold"),
                 fg=self.C["muted"], bg=self.C["bg"],
                 anchor="w").pack(fill="x", pady=(12,4))

    def _sb_btn(self, label, cmd):
        btn = tk.Button(
            self.sidebar, text=label, font=("Arial", 9),
            bg=self.C["sidebar_btn"], fg=self.C["text"],
            relief="flat", cursor="hand2", anchor="w", padx=10, pady=5,
            activebackground=self.C["primary"], activeforeground="white",
            command=lambda c=cmd: self._send_message(c)
        )
        btn.pack(fill="x", pady=2)
        return btn

    def _sb_stat(self, label, value):
        frame = tk.Frame(self.sidebar, bg=self.C["sidebar_btn"], relief="flat", bd=1)
        frame.pack(fill="x", pady=2)
        val_lbl = tk.Label(frame, text=value, font=("Arial", 13, "bold"),
                           fg=self.C["primary"], bg=self.C["sidebar_btn"])
        val_lbl.pack(pady=(4,0))
        tk.Label(frame, text=label, font=("Arial", 7),
                 fg=self.C["muted"], bg=self.C["sidebar_btn"]).pack(pady=(0,4))
        return val_lbl

    def _build_chat(self, parent):
        chat_outer = tk.Frame(parent, bg=self.C["card"], bd=1,
                              relief="flat", highlightthickness=1,
                              highlightbackground=self.C["border"])
        chat_outer.pack(side="left", fill="both", expand=True)

        ch = tk.Frame(chat_outer, bg="#1a3c6e", height=54)
        ch.pack(fill="x")
        ch.pack_propagate(False)
        tk.Label(ch, text="🤖  BankBot AI Assistant", font=("Arial", 11, "bold"),
                 fg="white", bg="#1a3c6e").pack(side="left", padx=14, pady=14)
        tk.Label(ch, text="● Online — Secure Session", font=("Arial", 8),
                 fg="#4ade80", bg="#1a3c6e").pack(side="left")

        self.chat_display = scrolledtext.ScrolledText(
            chat_outer, wrap="word", state="disabled",
            font=("Arial", 10), bg=self.C["card"], fg=self.C["text"],
            relief="flat", bd=0, padx=14, pady=10,
            cursor="arrow"
        )
        self.chat_display.pack(fill="both", expand=True)

        self.chat_display.tag_configure("bot",  foreground=self.C["bot_text"],
                                        background=self.C["bot_bubble"],
                                        lmargin1=10, lmargin2=10, rmargin=80,
                                        spacing1=6, spacing3=6)
        self.chat_display.tag_configure("user", foreground=self.C["user_text"],
                                        background=self.C["user_bubble"],
                                        lmargin1=80, lmargin2=80, rmargin=10,
                                        spacing1=6, spacing3=6, justify="right")
        self.chat_display.tag_configure("label_bot",  foreground=self.C["muted"],
                                        font=("Arial", 7), lmargin1=10, spacing1=4)
        self.chat_display.tag_configure("label_user", foreground=self.C["muted"],
                                        font=("Arial", 7), rmargin=10,
                                        spacing1=4, justify="right")
        self.chat_display.tag_configure("typing", foreground=self.C["muted"],
                                        font=("Arial", 10, "italic"), lmargin1=10)

        inp_frame = tk.Frame(chat_outer, bg=self.C["card"],
                             highlightthickness=1,
                             highlightbackground=self.C["border"])
        inp_frame.pack(fill="x", side="bottom")

        self.input_var = tk.StringVar()
        self.input_box = tk.Entry(
            inp_frame, textvariable=self.input_var,
            font=("Arial", 11), relief="flat", bd=0,
            bg=self.C["input_bg"], fg=self.C["text"],
            insertbackground=self.C["text"]
        )
        self.input_box.pack(side="left", fill="x", expand=True, padx=14, pady=12, ipady=6)
        self.input_box.bind("<Return>", lambda e: self._send_message())
        self.input_box.bind("<Up>",     self._history_up)

        send_btn = tk.Button(
            inp_frame, text="➤", font=("Arial", 12, "bold"),
            bg=self.C["primary"], fg="white", relief="flat",
            cursor="hand2", padx=14, pady=6,
            activebackground="#2b5aa0",
            command=self._send_message
        )
        send_btn.pack(side="right", padx=(0,10), pady=8)
        self.input_box.focus()

    def _send_message(self, prefill=None):
        text = prefill or self.input_var.get().strip()
        if not text:
            return
        self.input_var.set("")
        self._append_message("user", text)
        self._show_typing()
        t = threading.Thread(target=self._get_bot_reply, args=(text,), daemon=True)
        t.start()

    def _get_bot_reply(self, user_text):
        time.sleep(0.6)
        response = get_response(user_text, self.role)
        self.root.after(0, self._hide_typing)

        if response == "__EMI_CALC__":
            self.root.after(0, self._open_emi_window)
        else:
            self.root.after(0, lambda: self._append_message("bot", response))

    def _append_message(self, who, text):
        self.chat_display.config(state="normal")
        now   = time.strftime("%H:%M")
        label = f"  🤖 BankBot  {now}\n" if who == "bot" else f"  You  {now}\n"
        self.chat_display.insert("end", label, f"label_{who}")
        self.chat_display.insert("end", f"  {text}  \n\n", who)
        self.chat_display.config(state="disabled")
        self.chat_display.see("end")
        self.msg_count += 1
        self.msg_lbl.config(text=str(self.msg_count))
        self.chat_log.append({"who": who, "text": text, "time": now})

    def _show_typing(self):
        self.chat_display.config(state="normal")
        self.chat_display.insert("end", "  🤖 BankBot is typing...\n", "typing")
        self.chat_display.config(state="disabled")
        self.chat_display.see("end")

    def _hide_typing(self):
        self.chat_display.config(state="normal")
        content = self.chat_display.get("1.0", "end")
        if "BankBot is typing..." in content:
            idx = self.chat_display.search("🤖 BankBot is typing...", "1.0", "end")
            if idx:
                line_start = idx.split(".")[0]
                self.chat_display.delete(f"{line_start}.0", f"{int(line_start)+1}.0")
        self.chat_display.config(state="disabled")

    def _history_up(self, event):
        if self.chat_log:
            last_user = [m for m in self.chat_log if m["who"] == "user"]
            if last_user:
                self.input_var.set(last_user[-1]["text"])
                self.input_box.icursor("end")

    def _open_emi_window(self):
        win = tk.Toplevel(self.root)
        win.title("EMI Calculator")
        win.geometry("380x320")
        win.resizable(False, False)
        win.configure(bg="white")

        win.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width()  - 380) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 320) // 2
        win.geometry(f"380x320+{x}+{y}")

        tk.Label(win, text="🧮  EMI Calculator", font=("Arial", 13, "bold"),
                 fg="#1a3c6e", bg="white").pack(pady=(18,14))

        fields = {}
        for label, key, placeholder in [
            ("Loan Amount (INR)",        "p", "e.g. 500000"),
            ("Annual Interest Rate (%)", "r", "e.g. 9.5"),
            ("Tenure (months)",          "n", "e.g. 60"),
        ]:
            tk.Label(win, text=label, font=("Arial", 9, "bold"),
                     fg="#6b7280", bg="white", anchor="w").pack(fill="x", padx=24, pady=(6,1))
            var = tk.StringVar()
            tk.Entry(win, textvariable=var, font=("Arial", 11),
                     relief="solid", bd=1).pack(fill="x", padx=24, ipady=5)
            fields[key] = var

        result_lbl = tk.Label(win, text="", font=("Arial", 10),
                               fg="#1a3c6e", bg="#f0f4ff",
                               justify="left", anchor="w", padx=12, pady=8)
        result_lbl.pack(fill="x", padx=24, pady=(10,0))

        def calc():
            try:
                p = float(fields["p"].get().replace(",", ""))
                r = float(fields["r"].get())
                n = int(fields["n"].get())
                if p <= 0 or n <= 0 or r < 0:
                    raise ValueError
                emi, total, interest = calculate_emi(p, r, n)
                result_lbl.config(
                    text=(f"Monthly EMI:      ₹ {emi:>12,.2f}\n"
                          f"Total Interest:   ₹ {interest:>12,.2f}\n"
                          f"Total Repayment:  ₹ {total:>12,.2f}")
                )
            except (ValueError, ZeroDivisionError):
                result_lbl.config(text="⚠  Please enter valid positive numbers.")

        tk.Button(win, text="Calculate", font=("Arial", 10, "bold"),
                  bg="#1a3c6e", fg="white", relief="flat", padx=20, pady=6,
                  cursor="hand2", command=calc).pack(pady=(10,0))

    def _toggle_dark(self):
        self.dark_mode = not self.dark_mode
        self.C = DARK if self.dark_mode else LIGHT
        for w in self.root.winfo_children():
            w.destroy()
        self._build()
        self.root.after(400, lambda: self._get_bot_reply("hello"))

    def _start_session_timer(self):
        def tick():
            elapsed = int((time.time() - self.start_time) / 60)
            self.time_lbl.config(text=f"{elapsed}m")
            self.root.after(30000, tick)
        self.root.after(30000, tick)

    def _clear_chat(self):
        self.chat_display.config(state="normal")
        self.chat_display.delete("1.0", "end")
        self.chat_display.config(state="disabled")
        self.msg_count = 0
        self.msg_lbl.config(text="0")
        self.chat_log  = []
        self.root.after(300, lambda: self._get_bot_reply("hello"))

    def _export_chat(self):
        if not self.chat_log:
            messagebox.showinfo("Export", "No messages to export yet.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt")],
            initialfile="bankbot_session.txt"
        )
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write("BankBot AI — Chat Session Export\n")
                f.write("=" * 40 + "\n\n")
                for m in self.chat_log:
                    f.write(f"[{m['time']}] {m['who'].upper()}: {m['text']}\n\n")
            messagebox.showinfo("Export", f"Chat saved to:\n{path}")

    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.root.destroy()
            new_root = tk.Tk()
            LoginWindow(new_root)
            new_root.mainloop()


def main():
    root = tk.Tk()
    LoginWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()
