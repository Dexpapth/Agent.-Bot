# =============================================================
# BANKBOT AI — FLASK WEB APP
# =============================================================
# Run this file with:
#   pip install flask
#   python app.py
# Then open:  http://localhost:5000
#
# Routes:
#   GET  /           → serves the chat page
#   POST /login      → validates credentials, returns role
#   POST /chat       → processes message, returns bot reply
#   POST /emi        → calculates EMI, returns results
#   GET  /logout     → clears session
# =============================================================

import sys
import os

# Add parent directory to path so we can import chatbot_core
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from chatbot_core import get_response, verify_login, calculate_emi
from datetime import datetime

app = Flask(__name__)
# Secret key for session management — change this in production
app.secret_key = "bankbot_secret_key_2026_change_in_production"


# ── HOME ROUTE ────────────────────────────────────────────────

@app.route("/")
def index():
    """
    Serve the main chat page.
    If not logged in, redirect to login page.
    """
    if "role" not in session:
        return redirect(url_for("login_page"))
    return render_template("index.html", role=session["role"])


# ── LOGIN PAGE ────────────────────────────────────────────────

@app.route("/login", methods=["GET"])
def login_page():
    """Serve the login page."""
    return render_template("login.html")


@app.route("/login", methods=["POST"])
def do_login():
    """
    POST /login
    Body (JSON): { username, password, role }
    Returns:     { success: bool, message: str }
    """
    data     = request.get_json()
    username = data.get("username", "").strip()
    password = data.get("password", "")
    role     = data.get("role", "customer")

    if verify_login(username, password, role):
        session["role"]       = role
        session["username"]   = username
        session["login_time"] = datetime.now().strftime("%H:%M:%S")
        return jsonify({"success": True, "role": role})
    else:
        return jsonify({"success": False, "message": "Incorrect username or password."}), 401


# ── CHAT ROUTE ────────────────────────────────────────────────

@app.route("/chat", methods=["POST"])
def chat():
    """
    POST /chat
    Body (JSON): { message: str }
    Returns:     { reply: str, intent: str (optional) }
    Requires:    User must be logged in (session["role"] must exist)
    """
    if "role" not in session:
        return jsonify({"error": "Not authenticated"}), 401

    data    = request.get_json()
    message = data.get("message", "").strip()
    role    = session.get("role", "customer")

    if not message:
        return jsonify({"reply": "Please type a message."}), 400

    reply = get_response(message, role)

    # If the chatbot signals EMI calculator mode, return a special flag
    if reply == "__EMI_CALC__":
        return jsonify({
            "reply":    "emi_mode",
            "emi_mode": True
        })

    return jsonify({"reply": reply})


# ── EMI CALCULATOR ROUTE ──────────────────────────────────────

@app.route("/emi", methods=["POST"])
def emi():
    """
    POST /emi
    Body (JSON): { principal: float, rate: float, months: int }
    Returns:     { emi: float, total_payment: float, total_interest: float }
    """
    if "role" not in session:
        return jsonify({"error": "Not authenticated"}), 401

    data = request.get_json()
    try:
        principal   = float(data.get("principal", 0))
        annual_rate = float(data.get("rate", 0))
        months      = int(data.get("months", 0))

        if principal <= 0 or months <= 0 or annual_rate < 0:
            return jsonify({"error": "Please enter valid positive values."}), 400

        emi_val, total_payment, total_interest = calculate_emi(principal, annual_rate, months)

        return jsonify({
            "emi":            emi_val,
            "total_payment":  total_payment,
            "total_interest": total_interest,
            "principal":      principal,
            "months":         months,
            "rate":           annual_rate,
        })

    except (ValueError, TypeError):
        return jsonify({"error": "Invalid input. Numbers only."}), 400


# ── LOGOUT ROUTE ──────────────────────────────────────────────

@app.route("/logout")
def logout():
    """Clear session and redirect to login page."""
    session.clear()
    return redirect(url_for("login_page"))


# ── SESSION INFO ROUTE ────────────────────────────────────────

@app.route("/session-info")
def session_info():
    """Return current session information as JSON."""
    if "role" not in session:
        return jsonify({"logged_in": False})
    return jsonify({
        "logged_in":  True,
        "role":       session.get("role"),
        "username":   session.get("username"),
        "login_time": session.get("login_time"),
    })


# ── RUN ───────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 50)
    print("  BankBot AI — Flask Web Server")
    print("  Running at:  http://localhost:5000")
    print("  Press Ctrl+C to stop")
    print("=" * 50)
    app.run(debug=True, port=5000)
