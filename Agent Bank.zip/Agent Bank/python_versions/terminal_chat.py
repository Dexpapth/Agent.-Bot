import sys
import time
import getpass
from chatbot_core import (
    get_response, verify_login, calculate_emi, reply_greeting, CREDENTIALS
)
from datetime import datetime

try:
    from colorama import init, Fore, Style
    init(autoreset=True)
    HAS_COLOR = True
except ImportError:
    HAS_COLOR = False
    class Fore:
        BLUE = CYAN = GREEN = RED = YELLOW = WHITE = MAGENTA = ""
        RESET = ""
    class Style:
        BRIGHT = DIM = RESET_ALL = ""

def c(text, color="", bright=False):
    if not HAS_COLOR:
        return text
    b = Style.BRIGHT if bright else ""
    return f"{b}{color}{text}{Style.RESET_ALL}"

def print_divider():
    print(c("─" * 60, Fore.BLUE))

def print_header():
    print()
    print(c("=" * 60, Fore.BLUE, bright=True))
    print(c("   🏦  BankBot AI Agent — Terminal Edition", Fore.CYAN, bright=True))
    print(c("   Secure Banking Assistant  |  v2.1.0", Fore.CYAN))
    print(c("=" * 60, Fore.BLUE, bright=True))
    print()

def print_bot(text):
    print()
    print(c("  🤖  BankBot:", Fore.GREEN, bright=True))
    for line in text.split("\n"):
        print(c(f"      {line}", Fore.WHITE))
    print()

def print_system(text):
    print(c(f"  ℹ  {text}", Fore.YELLOW))

def print_error(text):
    print(c(f"  ✗  {text}", Fore.RED))

def print_success(text):
    print(c(f"  ✓  {text}", Fore.GREEN, bright=True))

def login():
    print_divider()
    print(c("  SECURE LOGIN", Fore.CYAN, bright=True))
    print_divider()
    print()
    print("  Select your role:")
    print(c("    1. Customer", Fore.WHITE))
    print(c("    2. Bank Employee", Fore.WHITE))
    print(c("    3. Administrator", Fore.WHITE))
    print()

    role_map = {"1": "customer", "2": "employee", "3": "admin"}
    while True:
        choice = input(c("  Enter choice (1/2/3): ", Fore.CYAN)).strip()
        if choice in role_map:
            role = role_map[choice]
            break
        print_error("Invalid choice. Enter 1, 2, or 3.")

    print()
    print(c(f"  Role selected: {role.upper()}", Fore.YELLOW))
    print(c(f"  Demo credentials -> username: {CREDENTIALS[role]['username']}  "
            f"password: {CREDENTIALS[role]['password']}", Fore.YELLOW, False))
    print()

    attempts = 0
    max_attempts = 3

    while attempts < max_attempts:
        username = input(c("  Username: ", Fore.CYAN)).strip()
        try:
            password = getpass.getpass(c("  Password: ", Fore.CYAN))
        except Exception:
            password = input(c("  Password: ", Fore.CYAN)).strip()

        if verify_login(username, password, role):
            print()
            print_success(f"Login successful! Welcome, {role.upper()}.")
            return role
        else:
            attempts += 1
            remaining = max_attempts - attempts
            if remaining > 0:
                print_error(f"Incorrect credentials. {remaining} attempt(s) remaining.")
            else:
                print_error("Too many failed attempts. Account locked for 30 seconds.")
                for i in range(30, 0, -1):
                    sys.stdout.write(c(f"\r  Locked — try again in {i} seconds...  ", Fore.RED))
                    sys.stdout.flush()
                    time.sleep(1)
                print()
                attempts = 0
                print_system("Lockout ended. You may try again.")
                print()

    return login()


def emi_calculator_interactive():
    print()
    print(c("  🧮  EMI Calculator", Fore.CYAN, bright=True))
    print_divider()

    try:
        principal   = float(input(c("  Loan Amount (INR): ", Fore.CYAN)).replace(",", ""))
        annual_rate = float(input(c("  Annual Interest Rate (%): ", Fore.CYAN)))
        months      = int(input(c("  Loan Tenure (months): ", Fore.CYAN)))

        if principal <= 0 or months <= 0 or annual_rate < 0:
            print_error("Please enter positive values.")
            return

        emi, total_payment, total_interest = calculate_emi(principal, annual_rate, months)

        print()
        print(c("  Results:", Fore.GREEN, bright=True))
        print_divider()
        print(c(f"  Monthly EMI:       INR {emi:>12,.2f}", Fore.WHITE, bright=True))
        print(c(f"  Total Interest:    INR {total_interest:>12,.2f}", Fore.YELLOW))
        print(c(f"  Total Repayment:   INR {total_payment:>12,.2f}", Fore.WHITE))
        print_divider()

    except ValueError:
        print_error("Invalid input. Please enter numbers only.")


def chat_loop(role):
    msg_count  = 0
    start_time = datetime.now()

    greeting = get_response("hello", role)
    print_bot(greeting)
    print_divider()
    print(c("  Type your message below. Type 'bye' to exit.", Fore.YELLOW))
    print(c(f"  Role: {role.upper()}   |   Session started: {start_time.strftime('%H:%M:%S')}", Fore.CYAN))
    print_divider()

    while True:
        try:
            user_input = input(c("\n  You: ", Fore.MAGENTA, bright=True)).strip()
        except (KeyboardInterrupt, EOFError):
            print()
            print_bot("Session interrupted. Goodbye!")
            break

        if not user_input:
            continue

        msg_count += 1

        if user_input.lower() in ("bye", "exit", "quit", "goodbye"):
            print_bot("Thank you for banking with BankBot AI.\nYour session has been securely ended.\nHave a wonderful day! Goodbye.")
            duration = (datetime.now() - start_time).seconds // 60
            print_system(f"Session ended. Messages exchanged: {msg_count} | Duration: {duration} min")
            break

        if user_input.lower() in ("role", "switch role", "change role"):
            print_system("To switch roles, restart the program.")
            continue

        response = get_response(user_input, role)

        if response == "__EMI_CALC__":
            emi_calculator_interactive()
            continue

        if user_input.upper() == "CONFIRM BLOCK":
            print_bot("Your card ending **** 9201 has been BLOCKED.\nPlease call 1800-XXX-XXXX to reactivate.\nFraud case reference: CASE-" + datetime.now().strftime("%Y%m%d%H%M"))
            continue

        print_bot(response)


def main():
    print_header()

    if not HAS_COLOR:
        print("  Tip: Install colorama for colored output:")
        print("       pip install colorama")
        print()

    role = login()
    chat_loop(role)


if __name__ == "__main__":
    main()
